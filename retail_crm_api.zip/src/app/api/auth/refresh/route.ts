import {
  successResponse,
  handleError,
} from "@/utils/response";


import {
  validate,
} from "@/validations/validate";


import {
  refreshTokenSchema,
} from "@/modules/auth/auth.validation";


import {
  refreshSession,
} from "@/modules/auth/auth.service";




// =========================
// REFRESH TOKEN
// =========================

export async function POST(

  request:Request,

) {


  try {


    const body =
      await request.json();



    const data =
      validate(

        refreshTokenSchema,

        body,

      );



    const result =
      await refreshSession(

        data.refreshToken,

      );



    return successResponse(

      result,

      "Token berhasil diperbarui",

    );



  } catch(error) {


    return handleError(error);


  }


}